package com.example.studyforge

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SeventhActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seventh)
    }
}