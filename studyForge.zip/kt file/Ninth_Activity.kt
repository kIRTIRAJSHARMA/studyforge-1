package com.example.studyforge

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Ninth_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ninth)
    }
}